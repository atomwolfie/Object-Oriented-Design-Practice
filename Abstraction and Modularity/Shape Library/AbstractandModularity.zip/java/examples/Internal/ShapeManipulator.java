package Internal;

import examples.shapes.Circle;
import examples.shapes.Shape;

public  class ShapeManipulator{
	
	
	
	public void scale(double scaleFactor){
		//to do????				
	};
	
	public void move(Shape shape) {
	
	//to do????
	};
	
	
	
}